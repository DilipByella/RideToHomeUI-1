export interface Post {
    busId: number;
    busName: string;
    source: string;
    destination: string;
    departureDate: string;
    departureTime: string;
    charges: number;
}